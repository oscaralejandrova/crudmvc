package Modelo;

import java.sql.*;

public class Conexion {
    
    private static Connection cnx = null; 
    
    public static Connection obtener() throws SQLException, ClassNotFoundException{
        
        if(cnx == null){
            
            try{
                
                class.forName("com.mysql.jdbc.driver");
                cnx = DriverManager.getConnection("jdbc:mysql://localhost/Tienda", "root","");
                
            }catch(SQLException ex){
                throw new SQLException(ex);
            }catch(ClassNotFoundException ex){
                throw new ClassCastException(ex.getMessage());
            }
        }   
                
         return cnx;       
                
    }
                
     public static void cerrar() throw SQLException {
         
         if(cnx != null){
                cnx.close();
  
            }
  
        }
               
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

